import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, ScanCommand } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const dynamodb = DynamoDBDocumentClient.from(client);

const USERS_TABLE = 'ShiftOrganizer-Users';

export const handler = async (event) => {
  console.log('Event:', JSON.stringify(event, null, 2));

  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
  };

  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  try {
    const groups = event.requestContext?.authorizer?.claims?.['cognito:groups'] || [];
    const isManager = groups.includes('Managers');

    if (!isManager) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({
          error: 'Unauthorized. Only managers can view all employees.'
        })
      };
    }

    const result = await dynamodb.send(
      new ScanCommand({ TableName: USERS_TABLE })
    );

    const employees = (result.Items || []).sort((a, b) =>
      (a.name || '').localeCompare(b.name || '')
    );

    const managers = employees.filter(emp => emp.role === 'manager');
    const regularEmployees = employees.filter(emp => emp.role !== 'manager');

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        employees,
        summary: {
          total: employees.length,
          managers: managers.length,
          employees: regularEmployees.length
        }
      })
    };
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'Internal server error',
        details: error.message
      })
    };
  }
};
