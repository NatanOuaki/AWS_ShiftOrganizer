import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  QueryCommand,
  ScanCommand
} from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const dynamodb = DynamoDBDocumentClient.from(client);

const SHIFTS_TABLE = 'ShiftOrganizer-Shifts';

export const handler = async (event) => {
  console.log('Event:', JSON.stringify(event, null, 2));

  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
  };

  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  try {
    const userSub = event.requestContext?.authorizer?.claims?.sub;
    const userGroups = event.requestContext?.authorizer?.claims?.['cognito:groups'] || [];
    const isManager = userGroups.includes('Managers');

    const queryParams = event.queryStringParameters || {};
    const employeeId = queryParams.employeeId;
    const startDate = queryParams.startDate;
    const endDate = queryParams.endDate;

    let shifts = [];

    if (employeeId || !isManager) {
      const targetEmployeeId = employeeId || userSub;

      if (startDate && endDate) {
        const result = await dynamodb.send(
          new QueryCommand({
            TableName: SHIFTS_TABLE,
            IndexName: 'employeeId-date-index',
            KeyConditionExpression: 'employeeId = :empId AND #date BETWEEN :start AND :end',
            ExpressionAttributeNames: {
              '#date': 'date'
            },
            ExpressionAttributeValues: {
              ':empId': targetEmployeeId,
              ':start': startDate,
              ':end': endDate
            }
          })
        );
        shifts = result.Items;
      } else {
        const result = await dynamodb.send(
          new QueryCommand({
            TableName: SHIFTS_TABLE,
            IndexName: 'employeeId-date-index',
            KeyConditionExpression: 'employeeId = :empId',
            ExpressionAttributeValues: {
              ':empId': targetEmployeeId
            }
          })
        );
        shifts = result.Items;
      }
    } else {
      const result = await dynamodb.send(new ScanCommand({
        TableName: SHIFTS_TABLE
      }));
      shifts = result.Items;

      if (startDate && endDate) {
        shifts = shifts.filter(shift =>
          shift.date >= startDate && shift.date <= endDate
        );
      }
    }

    shifts.sort((a, b) => {
      if (a.date === b.date) {
        return a.startTime.localeCompare(b.startTime);
      }
      return a.date.localeCompare(b.date);
    });

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        shifts,
        count: shifts.length,
        isManager
      })
    };

  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'Internal server error',
        details: error.message
      })
    };
  }
};
