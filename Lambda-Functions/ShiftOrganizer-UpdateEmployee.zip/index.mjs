import {
  CognitoIdentityProviderClient,
  AdminUpdateUserAttributesCommand,
  AdminListGroupsForUserCommand,
  AdminAddUserToGroupCommand,
  AdminRemoveUserFromGroupCommand
} from "@aws-sdk/client-cognito-identity-provider";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, UpdateCommand } from "@aws-sdk/lib-dynamodb";

const region = "eu-north-1";
const USER_POOL_ID = "eu-north-1_kFak5p6YU";
const USERS_TABLE = "ShiftOrganizer-Users";

const dynamodb = DynamoDBDocumentClient.from(new DynamoDBClient({ region }));
const cognito = new CognitoIdentityProviderClient({ region });

export const handler = async (event) => {
  console.log("Event:", JSON.stringify(event, null, 2));

  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type,Authorization",
    "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PUT,DELETE",
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }

  try {
    const userId = event.pathParameters?.employeeId;
    const body = JSON.parse(event.body || "{}");

    if (!userId) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Missing employeeId in path" }),
      };
    }

    const updateExpressions = [];
    const expressionAttributeNames = {};
    const expressionAttributeValues = {};
    const cognitoAttributes = [];

    
    if (body.name !== undefined) {
      updateExpressions.push("#name = :name");
      expressionAttributeNames["#name"] = "name";
      expressionAttributeValues[":name"] = body.name;
      cognitoAttributes.push({ Name: "name", Value: body.name });
    }

    
    if (body.phone !== undefined) {
      updateExpressions.push("#phone = :phone");
      expressionAttributeNames["#phone"] = "phone";
      expressionAttributeValues[":phone"] = body.phone;
      cognitoAttributes.push({ Name: "phone_number", Value: body.phone });
    }

    
    if (body.role !== undefined) {
      updateExpressions.push("#role = :role");
      expressionAttributeNames["#role"] = "role";
      expressionAttributeValues[":role"] = body.role;
    }

    
    if (body.smsEnabled !== undefined || body.emailEnabled !== undefined) {
      updateExpressions.push("#notif = :notif");
      expressionAttributeNames["#notif"] = "notificationPreferences";
      expressionAttributeValues[":notif"] = {
        sms: body.smsEnabled !== false,
        email: body.emailEnabled !== false,
      };
    }
       
    updateExpressions.push("#updatedAt = :updatedAt");
    expressionAttributeNames["#updatedAt"] = "updatedAt";
    expressionAttributeValues[":updatedAt"] = new Date().toISOString();

    if (updateExpressions.length === 1) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "No valid fields to update" }),
      };
    }


    const dbResult = await dynamodb.send(
      new UpdateCommand({
        TableName: USERS_TABLE,
        Key: { userId },
        UpdateExpression: "SET " + updateExpressions.join(", "),
        ExpressionAttributeNames: expressionAttributeNames,
        ExpressionAttributeValues: expressionAttributeValues,
        ReturnValues: "ALL_NEW",
      })
    );


    if (cognitoAttributes.length > 0) {
      await cognito.send(
        new AdminUpdateUserAttributesCommand({
          UserPoolId: USER_POOL_ID,
          Username: userId,
          UserAttributes: cognitoAttributes,
        })
      );
    }


    if (body.role) {
      const currentGroupsRes = await cognito.send(
        new AdminListGroupsForUserCommand({
          UserPoolId: USER_POOL_ID,
          Username: userId,
        })
      );

      const currentGroups = currentGroupsRes.Groups?.map((g) => g.GroupName) || [];
      const newGroup = body.role === "manager" ? "Managers" : "Employees";

      for (const group of currentGroups) {
        if (group !== newGroup) {
          await cognito.send(
            new AdminRemoveUserFromGroupCommand({
              UserPoolId: USER_POOL_ID,
              Username: userId,
              GroupName: group,
            })
          );
        }
      }

      if (!currentGroups.includes(newGroup)) {
        await cognito.send(
          new AdminAddUserToGroupCommand({
            UserPoolId: USER_POOL_ID,
            Username: userId,
            GroupName: newGroup,
          })
        );
      }
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        message: "Employee updated successfully",
        profile: dbResult.Attributes,
      }),
    };
  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Internal server error",
        details: error.message,
      }),
    };
  }
};
