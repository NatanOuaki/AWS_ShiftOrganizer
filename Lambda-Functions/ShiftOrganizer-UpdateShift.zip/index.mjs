import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  GetCommand,
  UpdateCommand
} from "@aws-sdk/lib-dynamodb";
import { SNSClient, PublishCommand } from "@aws-sdk/client-sns";

const client = new DynamoDBClient({});
const dynamodb = DynamoDBDocumentClient.from(client);
const sns = new SNSClient({});

const SHIFTS_TABLE = "ShiftOrganizer-Shifts";
const USERS_TABLE = "ShiftOrganizer-Users";

export const handler = async (event) => {
  console.log("Event:", JSON.stringify(event, null, 2));

  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type,Authorization",
    "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PUT,DELETE"
  };

  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: ""
    };
  }

  try {
    const shiftId = event.pathParameters?.shiftId;
    const body = JSON.parse(event.body || "{}");

    const userSub = event.requestContext?.authorizer?.claims?.sub;
    const groups = event.requestContext?.authorizer?.claims?.["cognito:groups"] || [];
    const isManager = groups.includes("Managers");

    if (!isManager) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({ error: "Only managers can update shifts." })
      };
    }

    const existingShift = await dynamodb.send(new GetCommand({
      TableName: SHIFTS_TABLE,
      Key: { shiftId }
    }));

    if (!existingShift.Item) {
      return {
        statusCode: 404,
        headers,
        body: JSON.stringify({ error: "Shift not found" })
      };
    }

    const allowedUpdates = ["date", "startTime", "endTime", "location", "notes", "employeeId", "employeeName"];
    const updateExpressions = [];
    const expressionAttributeNames = {};
    const expressionAttributeValues = {};

    for (const field of allowedUpdates) {
      if (body[field] !== undefined) {
        updateExpressions.push(`#${field} = :${field}`);
        expressionAttributeNames[`#${field}`] = field;
        expressionAttributeValues[`:${field}`] = body[field];
      }
    }

    expressionAttributeNames["#updatedAt"] = "updatedAt";
    expressionAttributeNames["#updatedBy"] = "updatedBy";
    expressionAttributeValues[":updatedAt"] = new Date().toISOString();
    expressionAttributeValues[":updatedBy"] = userSub;
    updateExpressions.push("#updatedAt = :updatedAt", "#updatedBy = :updatedBy");

    const result = await dynamodb.send(new UpdateCommand({
      TableName: SHIFTS_TABLE,
      Key: { shiftId },
      UpdateExpression: "SET " + updateExpressions.join(", "),
      ExpressionAttributeNames: expressionAttributeNames,
      ExpressionAttributeValues: expressionAttributeValues,
      ReturnValues: "ALL_NEW"
    }));

    if (body.employeeId || body.date || body.startTime || body.endTime) {
      await sendShiftUpdateNotification(result.Attributes, existingShift.Item);
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        message: "Shift updated successfully",
        shift: result.Attributes
      })
    };
  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Internal server error",
        details: error.message
      })
    };
  }
};

async function sendShiftUpdateNotification(newShift, oldShift) {
  try {
    const user = await dynamodb.send(new GetCommand({
      TableName: USERS_TABLE,
      Key: { userId: newShift.employeeId }
    }));

    const phone = user.Item?.phone;
    if (phone) {
      const message = `Your shift has been updated:\nDate: ${newShift.date}\nTime: ${newShift.startTime} - ${newShift.endTime}\nLocation: ${newShift.location || "TBD"}`;

      await sns.send(new PublishCommand({
        Message: message,
        PhoneNumber: phone
      }));
    }
  } catch (err) {
    console.error("Failed to send SNS notification:", err.message);
  }
}
