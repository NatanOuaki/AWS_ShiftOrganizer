import {
  CognitoIdentityProviderClient,
  AdminDeleteUserCommand,
} from "@aws-sdk/client-cognito-identity-provider";
import {
  DynamoDBClient,
} from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  GetCommand,
  DeleteCommand,
  QueryCommand,
} from "@aws-sdk/lib-dynamodb";

const cognito = new CognitoIdentityProviderClient({});
const ddbClient = DynamoDBDocumentClient.from(new DynamoDBClient({}));

const USERS_TABLE = "ShiftOrganizer-Users";
const SHIFTS_TABLE = "ShiftOrganizer-Shifts";

export const handler = async (event) => {
  console.log("Event:", JSON.stringify(event, null, 2));

  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type,Authorization",
    "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PUT,DELETE",
  };

  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ message: "Employee deleted successfully" })
    };
  }

  try {
    const employeeId = event.pathParameters?.employeeId;
    const USER_POOL_ID = process.env.USER_POOL_ID;
    if (!employeeId) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Employee ID is required" }),
      };
    }

    const userGroups = event.requestContext?.authorizer?.claims?.["cognito:groups"] || [];
    const isManager = userGroups.includes("Managers");

    if (!isManager) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({
          error: "Unauthorized. Only managers can delete employees.",
        }),
      };
    }

    const userResult = await ddbClient.send(
      new GetCommand({
        TableName: USERS_TABLE,
        Key: { userId: employeeId },
      })
    );

    if (!userResult.Item) {
      return {
        statusCode: 404,
        headers,
        body: JSON.stringify({ error: "Employee not found" }),
      };
    }

    const employee = userResult.Item;

    const today = new Date().toISOString().split("T")[0];

    const futureShifts = await ddbClient.send(
      new QueryCommand({
        TableName: SHIFTS_TABLE,
        IndexName: "employeeId-date-index",
        KeyConditionExpression: "employeeId = :empId AND #date >= :today",
        ExpressionAttributeNames: {
          "#date": "date",
        },
        ExpressionAttributeValues: {
          ":empId": employeeId,
          ":today": today,
        },
      })
    );

    if ((futureShifts.Items || []).length > 0) {
      return {
        statusCode: 409,
        headers,
        body: JSON.stringify({
          error: "Cannot delete employee with future shifts assigned",
          futureShifts: futureShifts.Items.length,
        }),
      };
    }

    try {
      await cognito.send(
        new AdminDeleteUserCommand({
          UserPoolId: USER_POOL_ID,
          Username: employeeId,
        })
      );
      console.log("Deleted from Cognito:", employeeId);
    } catch (cognitoError) {
      console.error("Cognito deletion error:", cognitoError.message);
    }

    await ddbClient.send(
      new DeleteCommand({
        TableName: USERS_TABLE,
        Key: { userId: employeeId },
      })
    );

    console.log("Deleted from DynamoDB:", employeeId);

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        message: "Employee deleted successfully",
        employeeId,
        employeeName: employee.name,
        employeeEmail: employee.email,
      }),
    };
  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Internal server error",
        details: error.message,
      }),
    };
  }
};
