import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, QueryCommand, PutCommand } from "@aws-sdk/lib-dynamodb";
import crypto from "crypto";

const client = new DynamoDBClient({ region: "eu-north-1" });
const dynamodb = DynamoDBDocumentClient.from(client);

const SHIFTS_TABLE = "ShiftOrganizer-Shifts";

export const handler = async (event) => {
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type,Authorization",
    "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PUT,DELETE",
  };

  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: "",
    };
  }

  let body;
  try {
    body = JSON.parse(event.body);
  } catch (err) {
    console.error("Failed to parse JSON:", err);
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: "Invalid JSON in request body" }),
    };
  }

  if (!body.employeeId || !body.date || !body.startTime || !body.endTime) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({
        error: "Missing required fields: employeeId, date, startTime, endTime",
      }),
    };
  }

  try {
    const userSub = event.requestContext.authorizer.claims.sub;
    const userEmail = event.requestContext.authorizer.claims.email;

    const shiftId = "shift_" + crypto.randomBytes(8).toString("hex");

    const queryResult = await dynamodb.send(
      new QueryCommand({
        TableName: SHIFTS_TABLE,
        IndexName: "employeeId-date-index",
        KeyConditionExpression: "employeeId = :empId AND #date = :date",
        ExpressionAttributeNames: {
          "#date": "date",
        },
        ExpressionAttributeValues: {
          ":empId": body.employeeId,
          ":date": body.date,
        },
      })
    );

    const hasConflict = queryResult.Items.some((shift) => {
      return body.startTime < shift.endTime && body.endTime > shift.startTime;
    });

    if (hasConflict) {
      return {
        statusCode: 409,
        headers,
        body: JSON.stringify({
          error: "Shift conflicts with existing shift",
        }),
      };
    }

    const shift = {
      shiftId,
      employeeId: body.employeeId,
      employeeName: body.employeeName || "",
      date: body.date,
      startTime: body.startTime,
      endTime: body.endTime,
      location: body.location || "",
      notes: body.notes || "",
      createdAt: new Date().toISOString(),
      createdBy: userSub,
      createdByEmail: userEmail,
      status: "scheduled",
    };

    await dynamodb.send(
      new PutCommand({
        TableName: SHIFTS_TABLE,
        Item: shift,
      })
    );

    return {
      statusCode: 201,
      headers,
      body: JSON.stringify({
        message: "Shift created successfully",
        shift,
      }),
    };
  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Internal server error",
        details: error.message,
      }),
    };
  }
};
