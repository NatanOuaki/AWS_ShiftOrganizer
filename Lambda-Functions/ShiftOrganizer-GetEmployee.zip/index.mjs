import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  GetCommand
} from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const dynamodb = DynamoDBDocumentClient.from(client);
const USERS_TABLE = "ShiftOrganizer-Users";

export const handler = async (event) => {
  console.log("Event:", JSON.stringify(event, null, 2));

  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type,Authorization",
    "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PUT,DELETE"
  };

  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: ""
    };
  }

  const userId = event.pathParameters?.employeeId;

  try {
    const groups = event.requestContext?.authorizer?.claims?.["cognito:groups"] || [];
    const isManager = groups.includes("Managers");

    if (!isManager) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({
          error: "Unauthorized. Only managers can access employee data."
        })
      };
    }

    if (event.httpMethod === "GET" && userId) {
      const result = await dynamodb.send(
        new GetCommand({
          TableName: USERS_TABLE,
          Key: { userId }
        })
      );

      if (!result.Item) {
        return {
          statusCode: 404,
          headers,
          body: JSON.stringify({ error: "Employee not found" })
        };
      }

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(result.Item)
      };
    }

    // No fallback: reject all other requests
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: "Bad request: userId required for GET" })
    };
  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Internal server error",
        details: error.message
      })
    };
  }
};