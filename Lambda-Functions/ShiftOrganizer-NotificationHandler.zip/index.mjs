import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, ScanCommand, GetCommand, PutCommand } from "@aws-sdk/lib-dynamodb";
import { SNSClient, PublishCommand } from "@aws-sdk/client-sns";
import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";
import crypto from "crypto";

const ddbClient = new DynamoDBClient({ region: "eu-north-1" });
const dynamodb = DynamoDBDocumentClient.from(ddbClient);
const sns = new SNSClient({ region: "eu-north-1" });
const ses = new SESClient({ region: "eu-north-1" });

const SHIFTS_TABLE = "ShiftOrganizer-Shifts";
const USERS_TABLE = "ShiftOrganizer-Users";
const NOTIFICATIONS_TABLE = "ShiftOrganizer-Notifications";

export const handler = async (event) => {
  console.log("Notification handler triggered:", new Date().toISOString());

  try {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowDate = tomorrow.toISOString().split("T")[0];

    const shiftsResult = await dynamodb.send(
      new ScanCommand({
        TableName: SHIFTS_TABLE,
        FilterExpression: "#date = :tomorrow",
        ExpressionAttributeNames: {
          "#date": "date"
        },
        ExpressionAttributeValues: {
          ":tomorrow": tomorrowDate
        }
      })
    );

    const shifts = shiftsResult.Items || [];
    console.log(`Found ${shifts.length} shifts for tomorrow`);

    const notifications = [];

    for (const shift of shifts) {
      try {
        const userResult = await dynamodb.send(
          new GetCommand({
            TableName: USERS_TABLE,
            Key: { userId: shift.employeeId }
          })
        );

        const user = userResult.Item;

        if (!user) {
          console.error(`User not found: ${shift.employeeId}`);
          continue;
        }

        const notificationId = "notif_" + crypto.randomBytes(8).toString("hex");
        const message = formatShiftReminder(shift, user.name);

        const notifLog = [];

        if (user.notificationPreferences?.sms && user.phone) {
          try {
            await sns.send(
              new PublishCommand({
                Message: message.sms,
                PhoneNumber: user.phone
              })
            );
            notifLog.push({ notificationId, type: "sms", status: "sent" });
          } catch (err) {
            console.error(`SMS failed for ${user.phone}:`, err);
            notifLog.push({ notificationId, type: "sms", status: "failed", error: err.message });
          }
        }

        if (user.notificationPreferences?.email && user.email) {
          try {
            await ses.send(
              new SendEmailCommand({
                Destination: {
                  ToAddresses: [user.email]
                },
                Message: {
                  Body: {
                    Html: { Data: message.email }
                  },
                  Subject: {
                    Data: "Shift Reminder - Tomorrow"
                  }
                },
                Source: "omerdahan15@gmail.com"
              })
            );
            notifLog.push({ notificationId, type: "email", status: "sent" });
          } catch (err) {
            console.error(`Email failed for ${user.email}:`, err);
            notifLog.push({ notificationId, type: "email", status: "failed", error: err.message });
          }
        }

        await dynamodb.send(
          new PutCommand({
            TableName: NOTIFICATIONS_TABLE,
            Item: {
              notificationId,
              shiftId: shift.shiftId,
              employeeId: shift.employeeId,
              sentAt: new Date().toISOString(),
              notifications: notifLog,
              shiftDate: shift.date,
              shiftTime: `${shift.startTime} - ${shift.endTime}`
            }
          })
        );

        notifications.push(...notifLog);
      } catch (err) {
        console.error(`Error processing shift ${shift.shiftId}:`, err);
      }
    }

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Notifications processed",
        shiftsProcessed: shifts.length,
        notificationsSent: notifications.filter((n) => n.status === "sent").length
      })
    };
  } catch (error) {
    console.error("Error in notification handler:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Failed to process notifications",
        details: error.message
      })
    };
  }
};

function formatShiftReminder(shift, employeeName) {
  const time = `${shift.startTime} - ${shift.endTime}`;
  const location = shift.location || "Main Office";

  return {
    sms: `Hi ${employeeName}, reminder: You have a shift tomorrow (${shift.date}) from ${time} at ${location}`,
    email: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #FF9900;">Shift Reminder</h2>
          <p>Hi ${employeeName},</p>
          <p>This is a reminder that you have a shift scheduled for tomorrow:</p>
          <div style="background-color: #f5f5f5; padding: 20px; border-radius: 5px; margin: 20px 0;">
              <p><strong>Date:</strong> ${shift.date}</p>
              <p><strong>Time:</strong> ${time}</p>
              <p><strong>Location:</strong> ${location}</p>
              ${shift.notes ? `<p><strong>Notes:</strong> ${shift.notes}</p>` : ""}
          </div>
          <p>Please make sure to arrive on time.</p>
          <p>Best regards,<br>ShiftOrganizer Team</p>
      </div>
    `
  };
}
