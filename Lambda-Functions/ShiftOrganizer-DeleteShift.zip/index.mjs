import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  GetCommand,
  DeleteCommand
} from "@aws-sdk/lib-dynamodb";
import { SNSClient, PublishCommand } from "@aws-sdk/client-sns";

const client = new DynamoDBClient({});
const dynamodb = DynamoDBDocumentClient.from(client);
const sns = new SNSClient({});

const SHIFTS_TABLE = 'ShiftOrganizer-Shifts';
const USERS_TABLE = 'ShiftOrganizer-Users';

export const handler = async (event) => {
  console.log('Event:', JSON.stringify(event, null, 2));

  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE'
  };

  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  try {
    const shiftId = event.pathParameters?.shiftId;
    const userGroups = event.requestContext?.authorizer?.claims?.['cognito:groups'] || [];
    const isManager = userGroups.includes('Managers');

    if (!isManager) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({
          error: 'Unauthorized. Only managers can delete shifts.'
        })
      };
    }

    const shiftResult = await dynamodb.send(new GetCommand({
      TableName: SHIFTS_TABLE,
      Key: { shiftId }
    }));

    if (!shiftResult.Item) {
      return {
        statusCode: 404,
        headers,
        body: JSON.stringify({
          error: 'Shift not found'
        })
      };
    }

    const shift = shiftResult.Item;

    await dynamodb.send(new DeleteCommand({
      TableName: SHIFTS_TABLE,
      Key: { shiftId }
    }));

    await sendCancellationNotification(shift);

    return {
      statusCode: 204,
      headers,
      body: ''
    };
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'Internal server error',
        details: error.message
      })
    };
  }
};

async function sendCancellationNotification(shift) {
  try {
    const userResult = await dynamodb.send(new GetCommand({
      TableName: USERS_TABLE,
      Key: { userId: shift.employeeId }
    }));

    if (userResult.Item?.phone) {
      const message = `Your shift has been cancelled:\nDate: ${shift.date}\nTime: ${shift.startTime} - ${shift.endTime}`;
      await sns.send(new PublishCommand({
        Message: message,
        PhoneNumber: userResult.Item.phone
      }));
    }
  } catch (error) {
    console.error('Failed to send cancellation notification:', error);
  }
}
