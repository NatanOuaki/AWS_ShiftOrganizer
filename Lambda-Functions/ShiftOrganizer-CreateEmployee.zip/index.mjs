import {
    CognitoIdentityProviderClient,
    AdminCreateUserCommand,
    AdminAddUserToGroupCommand,
  } from "@aws-sdk/client-cognito-identity-provider";
  import { DynamoDBClient, PutItemCommand } from "@aws-sdk/client-dynamodb";
  import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";
  
  const cognito = new CognitoIdentityProviderClient({ region: "eu-north-1" });
  const dynamodb = new DynamoDBClient({ region: "eu-north-1" });
  const ses = new SESClient({ region: "eu-north-1" });
  
  const USERS_TABLE = "ShiftOrganizer-Users";
  const USER_POOL_ID = "eu-north-1_kFak5p6YU";
  
  export const handler = async (event) => {
    console.log("Event:", JSON.stringify(event, null, 2));
  
    const headers = {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type,Authorization",
      "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PUT,DELETE",
    };
  
    if (event.httpMethod === "OPTIONS") {
      return {
        statusCode: 200,
        headers,
        body: "",
      };
    }
  
    try {
      const body = JSON.parse(event.body);
  
      if (!body.email || !body.name || !body.phone) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({
            error: "Missing required fields: email, name, phone",
          }),
        };
      }
  
      const userGroups =
        event.requestContext.authorizer?.claims["cognito:groups"] || [];
      const isManager = userGroups.includes("Managers");
  
      if (!isManager) {
        return {
          statusCode: 403,
          headers,
          body: JSON.stringify({
            error: "Unauthorized. Only managers can create employees.",
          }),
        };
      }
  
      const tempPassword = "!Test12345";
  
      const createUserCmd = new AdminCreateUserCommand({
        UserPoolId: USER_POOL_ID,
        Username: body.email,
        UserAttributes: [
          { Name: "email", Value: body.email },
          { Name: "name", Value: body.name },
          { Name: "phone_number", Value: body.phone },
          { Name: "email_verified", Value: "true" },
        ],
        TemporaryPassword: tempPassword,
        MessageAction: "SUPPRESS",
      });
  
      const createResult = await cognito.send(createUserCmd);
      const userId = createResult.User.Username;
  
      const groupName = body.role === "manager" ? "Managers" : "Employees";
  
      await cognito.send(
        new AdminAddUserToGroupCommand({
          UserPoolId: USER_POOL_ID,
          Username: userId,
          GroupName: groupName,
        })
      );
  
      const putCmd = new PutItemCommand({
        TableName: USERS_TABLE,
        Item: {
          userId: { S: userId },
          email: { S: body.email },
          name: { S: body.name },
          phone: { S: body.phone },
          role: { S: body.role || "employee" },
          notificationPreferences: {
            M: {
              sms: { BOOL: body.smsEnabled !== false },
              email: { BOOL: body.emailEnabled !== false },
            },
          },
          createdAt: { S: new Date().toISOString() },
          createdBy: {
            S: event.requestContext.authorizer.claims.sub || "system",
          },
        },
      });
  
      await dynamodb.send(putCmd);
  
      await sendWelcomeEmail(body.email, body.name, tempPassword);
  
      return {
        statusCode: 201,
        headers,
        body: JSON.stringify({
          message: "Employee created successfully",
          userId,
          email: body.email,
          role: body.role || "employee",
        }),
      };
    } catch (error) {
      console.error("Error:", error);
  
      const statusCode = error.name === "UsernameExistsException" ? 409 : 500;
      const message =
        error.name === "UsernameExistsException"
          ? "User with this email already exists"
          : "Internal server error";
  
      return {
        statusCode,
        headers,
        body: JSON.stringify({
          error: message,
          details: error.message,
        }),
      };
    }
  };
  
  
  async function sendWelcomeEmail(email, name, tempPassword) {
    const sendCmd = new SendEmailCommand({
      Destination: {
        ToAddresses: [email],
      },
      Message: {
        Body: {
          Html: {
            Data: `
              <h2>Welcome to ShiftOrganizer!</h2>
              <p>Hi ${name},</p>
              <p>Your account has been created. Here are your login details:</p>
              <p><strong>Email:</strong> ${email}<br>
              <strong>Temporary Password:</strong> ${tempPassword}</p>
              <p>Please log in and change your password immediately.</p>
              <p>Best regards,<br>ShiftOrganizer Team</p>
            `,
          },
        },
        Subject: {
          Data: "Welcome to ShiftOrganizer",
        },
      },
      Source: "omerdahan15@gmail.com",
    });
  
    try {
      await ses.send(sendCmd);
    } catch (err) {
      console.error("Failed to send welcome email:", err);
    }
  }
  